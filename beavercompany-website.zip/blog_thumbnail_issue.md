# 블로그 썸네일 이미지 문제 진단

## 문제 상황
- 블로그 섹션에서 썸네일 이미지가 표시되지 않고 "🎭 블로그에서 확인하세요" 기본 아이콘만 표시됨

## 확인된 사항

### 1. API 응답 확인
```json
{
  "title": "경북 대구 어린이집 공연 [비버컴퍼니] 김천효동어린이집 솜사탕쇼 후기",
  "thumbnail": "https://blogthumb.pstatic.net/MjAyNjAxMDdfMjgg/MDAxNzY3NzczNzQyMjU2.xWHy6BZsghUErYyOWs5sgKPR8-QG0WJHU1ZXYHl7g9sg.D8wviwl51A3FD6UOdd28W0r8SqU34SNsgFCp8jozXB4g.JPEG/IMG%A3%DF7444.JPG?type=s3"
}
```
- 썸네일 URL이 정상적으로 반환되고 있음

### 2. 코드 확인
- Home.tsx에 썸네일 이미지 표시 로직이 이미 구현되어 있음
- `post.thumbnail`이 있으면 이미지를 표시하고, 없으면 기본 아이콘 표시
- `onError` 핸들러로 이미지 로드 실패 시 폴백 처리

### 3. 브라우저 확인
- 실제 페이지에서 모든 블로그 카드가 기본 아이콘(🎭)만 표시됨
- 이미지 로드가 실패하여 `onError` 핸들러가 실행된 것으로 추정

## 원인 분석

### CORS (Cross-Origin Resource Sharing) 문제
- 네이버 블로그 썸네일 이미지 서버(`blogthumb.pstatic.net`)는 외부 사이트에서 직접 로드하는 것을 제한할 가능성이 높음
- 브라우저가 보안상의 이유로 이미지 로드를 차단함

### Referer 정책 문제
- 네이버는 Referer 헤더를 확인하여 자사 도메인이 아닌 경우 이미지 로드를 차단할 수 있음

## 해결 방안

### 방안 1: 서버 프록시 사용 (권장)
- 서버에서 이미지를 가져와서 클라이언트에 전달
- `/api/proxy-image?url=<thumbnail_url>` 엔드포인트 생성
- 장점: CORS 문제 완전 해결, 캐싱 가능
- 단점: 서버 리소스 사용

### 방안 2: 기본 이미지 개선
- 현재 폴백 이미지를 더 시각적으로 개선
- 블로그 카테고리별로 다른 기본 이미지 사용
- 장점: 구현 간단, 서버 리소스 불필요
- 단점: 실제 썸네일 표시 불가

### 방안 3: 블로그 RSS 파싱 개선
- RSS 피드에서 `<description>` 태그 내의 이미지 URL 추출
- 네이버 블로그 본문 이미지는 `blogfiles.pstatic.net` 도메인 사용 (썸네일보다 제한이 적을 수 있음)
- 장점: 더 많은 이미지 소스 확보
- 단점: 파싱 로직 복잡도 증가
