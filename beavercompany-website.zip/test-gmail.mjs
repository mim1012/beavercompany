import "dotenv/config";
import nodemailer from "nodemailer";

const GMAIL_USER = process.env.GMAIL_USER;
const GMAIL_APP_PASSWORD = process.env.GMAIL_APP_PASSWORD;
const CONTACT_EMAIL = process.env.CONTACT_EMAIL;

console.log("🧪 Gmail SMTP 테스트 메일 발송 시작...\n");
console.log(`📤 발신자: ${GMAIL_USER}`);
console.log(`📧 수신자: ${CONTACT_EMAIL}\n`);

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: GMAIL_USER,
    pass: GMAIL_APP_PASSWORD,
  },
});

const html = `
  <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <h2 style="color: #F59E0B; border-bottom: 2px solid #F59E0B; padding-bottom: 10px;">
      🎭 테스트 메일 - 비버컴퍼니 이메일 알림 시스템
    </h2>
    <div style="background-color: #FEF9E7; padding: 20px; border-radius: 8px; margin: 20px 0;">
      <h3 style="margin-top: 0; color: #78350F;">✅ 이메일 발송 테스트 성공!</h3>
      <p>비버컴퍼니 웹사이트의 이메일 알림 시스템이 정상적으로 작동하고 있습니다.</p>
      <p><strong>발송 시각:</strong> ${new Date().toLocaleString("ko-KR", { timeZone: "Asia/Seoul" })}</p>
    </div>
    <div style="background-color: #ffffff; padding: 20px; border: 1px solid #E5E7EB; border-radius: 8px;">
      <h3 style="margin-top: 0; color: #78350F;">테스트 문의 내용</h3>
      <p><strong>기관명:</strong> 테스트 유치원</p>
      <p><strong>연락처:</strong> 010-1234-5678</p>
      <p><strong>공연 종류:</strong> 솜사탕쇼</p>
      <p><strong>희망 날짜:</strong> 2026년 3월 15일</p>
      <p><strong>문의 내용:</strong> 이메일 발송 테스트입니다. 실제 문의가 접수되면 이와 같은 형식으로 메일이 발송됩니다.</p>
    </div>
    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #E5E7EB; text-align: center; color: #6B7280; font-size: 12px;">
      <p>비버컴퍼니 - 유치원·초등학교 방문 공연 전문</p>
      <p>📞 010-4808-9382 | 🌐 beavercompany.co.kr</p>
    </div>
  </div>
`;

try {
  const info = await transporter.sendMail({
    from: `"비버컴퍼니" <${GMAIL_USER}>`,
    to: CONTACT_EMAIL,
    subject: "[비버컴퍼니] 이메일 발송 테스트",
    html,
  });

  console.log("✅ 메일 발송 성공!");
  console.log(`📬 Message ID: ${info.messageId}`);
  console.log(`\n💡 ${CONTACT_EMAIL} 네이버 메일함을 확인해주세요!`);
} catch (error) {
  console.error("❌ 메일 발송 실패:", error.message);
  process.exit(1);
}
