CREATE TABLE `consultations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organization` varchar(255) NOT NULL,
	`phone` varchar(20) NOT NULL,
	`performance` varchar(100),
	`date` varchar(50),
	`message` text NOT NULL,
	`status` enum('pending','contacted','completed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `consultations_id` PRIMARY KEY(`id`)
);
