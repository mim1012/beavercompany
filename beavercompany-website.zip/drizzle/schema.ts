import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * 상담 신청 테이블
 * 사용자가 공연 문의 폼을 통해 제출한 상담 신청 내역을 저장합니다.
 */
export const consultations = mysqlTable("consultations", {
  id: int("id").autoincrement().primaryKey(),
  /** 기관명 또는 이름 */
  organization: varchar("organization", { length: 255 }).notNull(),
  /** 연락처 */
  phone: varchar("phone", { length: 20 }).notNull(),
  /** 희망 공연 종류 */
  performance: varchar("performance", { length: 100 }),
  /** 희망 날짜 */
  date: varchar("date", { length: 50 }),
  /** 문의 내용 */
  message: text("message").notNull(),
  /** 유입 경로 (구글 검색, 네이버 검색, 직접 접속 등) */
  source: varchar("source", { length: 100 }),
  /** 유입 매체 (organic, direct, social, referral) */
  medium: varchar("medium", { length: 50 }),
  /** UTM 캠페인 */
  campaign: varchar("campaign", { length: 100 }),
  /** 레퍼러 URL */
  referrerUrl: text("referrerUrl"),
  /** 상태: pending(대기중), contacted(연락완료), completed(완료) */
  status: mysqlEnum("status", ["pending", "contacted", "completed"]).default("pending").notNull(),
  /** 생성 시간 */
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  /** 수정 시간 */
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Consultation = typeof consultations.$inferSelect;
export type InsertConsultation = typeof consultations.$inferInsert;

// TODO: Add your tables here
