ALTER TABLE `consultations` ADD `source` varchar(100);--> statement-breakpoint
ALTER TABLE `consultations` ADD `medium` varchar(50);--> statement-breakpoint
ALTER TABLE `consultations` ADD `campaign` varchar(100);--> statement-breakpoint
ALTER TABLE `consultations` ADD `referrerUrl` text;