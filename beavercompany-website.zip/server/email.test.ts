import { describe, it, expect } from "vitest";
import { ENV } from "./_core/env";

describe("Gmail SMTP Configuration", () => {
  it("should have GMAIL_USER configured", () => {
    expect(ENV.gmailUser).toBeTruthy();
    expect(ENV.gmailUser).toContain("@gmail.com");
  });

  it("should have GMAIL_APP_PASSWORD configured", () => {
    expect(ENV.gmailAppPassword).toBeTruthy();
    expect(ENV.gmailAppPassword.length).toBeGreaterThan(10);
  });

  it("should have CONTACT_EMAIL configured", () => {
    expect(ENV.contactEmail).toBeTruthy();
    expect(ENV.contactEmail).toContain("@");
  });
});
