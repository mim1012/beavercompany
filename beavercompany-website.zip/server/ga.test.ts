import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import { resolve } from 'path';

describe('GA4 설정 검증', () => {
  it('index.html에 GA4 스크립트 태그가 있어야 함', () => {
    const html = readFileSync(resolve(__dirname, '../client/index.html'), 'utf-8');
    expect(html).toContain('googletagmanager.com/gtag/js');
    expect(html).toContain('VITE_GA_MEASUREMENT_ID');
  });

  it('analytics.ts 파일이 존재해야 함', () => {
    const fs = require('fs');
    const exists = fs.existsSync(resolve(__dirname, '../client/src/lib/analytics.ts'));
    expect(exists).toBe(true);
  });

  it('analytics.ts에 핵심 트래킹 함수가 있어야 함', () => {
    const content = readFileSync(resolve(__dirname, '../client/src/lib/analytics.ts'), 'utf-8');
    expect(content).toContain('trackPhoneClick');
    expect(content).toContain('trackKakaoClick');
    expect(content).toContain('trackConsultationSubmit');
  });
});
