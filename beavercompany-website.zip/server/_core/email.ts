import nodemailer from "nodemailer";
import { ENV } from "./env";

/**
 * Gmail SMTP 트랜스포터 생성
 */
function createTransporter() {
  return nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: ENV.gmailUser,
      pass: ENV.gmailAppPassword,
    },
  });
}

export interface SendEmailOptions {
  to: string;
  subject: string;
  html: string;
}

/**
 * Gmail SMTP를 통해 이메일 발송
 */
export async function sendEmail(options: SendEmailOptions): Promise<boolean> {
  if (!ENV.gmailUser || !ENV.gmailAppPassword) {
    console.error("[Email] Gmail 인증 정보가 설정되지 않았습니다");
    return false;
  }

  try {
    const transporter = createTransporter();
    const info = await transporter.sendMail({
      from: `"비버컴퍼니" <${ENV.gmailUser}>`,
      to: options.to,
      subject: options.subject,
      html: options.html,
    });
    console.log("[Email] 이메일 발송 성공:", info.messageId);
    return true;
  } catch (error) {
    console.error("[Email] 이메일 발송 실패:", error);
    return false;
  }
}

/**
 * 문의 접수 알림 이메일 발송 (유입 경로 포함)
 */
export async function sendContactNotification(data: {
  name: string;
  phone: string;
  email?: string;
  message: string;
  preferredDate?: string;
  programType?: string;
  source?: string;
  medium?: string;
  campaign?: string;
  referrerUrl?: string;
}): Promise<boolean> {
  const contactEmail = ENV.contactEmail;

  if (!contactEmail) {
    console.error("[Email] CONTACT_EMAIL이 설정되지 않았습니다");
    return false;
  }

  const sourceLabel = data.source || "직접 접속";
  const mediumLabel = data.medium || "direct";

  // 유입 경로 뱃지 색상
  const sourceBadgeColor =
    mediumLabel === "organic" ? "#16A34A" :
    mediumLabel === "social" ? "#2563EB" :
    mediumLabel === "referral" ? "#7C3AED" : "#6B7280";

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #F59E0B; border-bottom: 2px solid #F59E0B; padding-bottom: 10px;">
        🎭 새로운 공연 문의가 접수되었습니다
      </h2>

      <!-- 유입 경로 뱃지 -->
      <div style="margin-bottom: 16px;">
        <span style="display: inline-block; background-color: ${sourceBadgeColor}; color: white; padding: 5px 14px; border-radius: 20px; font-size: 13px; font-weight: bold;">
          📊 ${sourceLabel}
        </span>
        ${data.campaign ? `<span style="display: inline-block; background-color: #F59E0B; color: white; padding: 5px 14px; border-radius: 20px; font-size: 13px; margin-left: 6px;">캠페인: ${data.campaign}</span>` : ""}
      </div>

      <div style="background-color: #FEF9E7; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin-top: 0; color: #78350F;">문의자 정보</h3>
        <p><strong>기관명:</strong> ${data.name}</p>
        <p><strong>연락처:</strong> ${data.phone}</p>
        ${data.email ? `<p><strong>이메일:</strong> ${data.email}</p>` : ""}
        ${data.programType ? `<p><strong>공연 종류:</strong> ${data.programType}</p>` : ""}
        ${data.preferredDate ? `<p><strong>희망 날짜:</strong> ${data.preferredDate}</p>` : ""}
      </div>

      <div style="background-color: #ffffff; padding: 20px; border: 1px solid #E5E7EB; border-radius: 8px;">
        <h3 style="margin-top: 0; color: #78350F;">문의 내용</h3>
        <p style="white-space: pre-wrap;">${data.message}</p>
      </div>

      <!-- 유입 경로 상세 -->
      <div style="margin-top: 16px; padding: 16px; background-color: #F0FDF4; border: 1px solid #BBF7D0; border-radius: 8px;">
        <h4 style="margin: 0 0 10px 0; color: #166534; font-size: 14px;">📈 유입 경로 정보</h4>
        <table style="width: 100%; font-size: 13px; color: #166534; border-collapse: collapse;">
          <tr>
            <td style="padding: 3px 0; width: 100px;"><strong>유입 경로</strong></td>
            <td style="padding: 3px 0;">${sourceLabel}</td>
          </tr>
          <tr>
            <td style="padding: 3px 0;"><strong>유입 매체</strong></td>
            <td style="padding: 3px 0;">${mediumLabel}</td>
          </tr>
          ${data.campaign ? `<tr><td style="padding: 3px 0;"><strong>캠페인</strong></td><td style="padding: 3px 0;">${data.campaign}</td></tr>` : ""}
          ${data.referrerUrl ? `<tr><td style="padding: 3px 0; vertical-align: top;"><strong>레퍼러</strong></td><td style="padding: 3px 0; word-break: break-all; font-size: 11px;">${data.referrerUrl}</td></tr>` : ""}
        </table>
      </div>

      <div style="margin-top: 20px; padding: 15px; background-color: #FEF3C7; border-left: 4px solid #F59E0B; border-radius: 4px;">
        <p style="margin: 0; color: #78350F;">
          💡 <strong>안내:</strong> 가능한 빠른 시일 내에 연락 부탁드립니다.
        </p>
      </div>

      <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #E5E7EB; text-align: center; color: #6B7280; font-size: 12px;">
        <p>비버컴퍼니 - 유치원·초등학교 방문 공연 전문</p>
        <p>📞 010-4808-9382 | 🌐 beavercompany.co.kr</p>
      </div>
    </div>
  `;

  return sendEmail({
    to: contactEmail,
    subject: `[비버컴퍼니] 새 문의 - ${data.name}님 [${sourceLabel}]`,
    html,
  });
}
