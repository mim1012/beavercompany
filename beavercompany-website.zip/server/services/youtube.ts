export interface YoutubeVideo {
  id: string;
  title: string;
  thumbnail: string;
  publishedAt: string;
  url: string;
}

// 비버컴퍼니 유튜브 채널 ID (추정)
// 실제로는 YouTube Data API를 사용해야 하지만, 여기서는 예시 데이터를 반환하거나
// RSS 피드를 파싱하는 방식으로 구현할 수 있습니다.
// 현재는 프로토타입이므로 정적 데이터를 반환하되, 추후 API 연동이 가능하도록 구조를 잡습니다.

const MOCK_VIDEOS: YoutubeVideo[] = [
  {
    id: "video1",
    title: "2024 찾아가는 인형극 하이라이트",
    thumbnail: "/images/puppet_show_v2.png",
    publishedAt: "2024-12-20",
    url: "https://youtube.com/watch?v=video1"
  },
  {
    id: "video2",
    title: "아이들의 웃음이 끊이지 않는 버블쇼",
    thumbnail: "/images/bubble_show_v2.png",
    publishedAt: "2024-11-15",
    url: "https://youtube.com/watch?v=video2"
  },
  {
    id: "video3",
    title: "신기한 마술쇼 현장 스케치",
    thumbnail: "/images/magic_show_v2.png",
    publishedAt: "2024-10-30",
    url: "https://youtube.com/watch?v=video3"
  }
];

export async function getYoutubeVideos(limit: number = 3): Promise<YoutubeVideo[]> {
  // TODO: 실제 YouTube Data API 연동
  // const API_KEY = process.env.YOUTUBE_API_KEY;
  // const CHANNEL_ID = 'UC...';
  
  return MOCK_VIDEOS.slice(0, limit);
}
