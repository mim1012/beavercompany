export interface VideoInfo {
  id: string;
  title: string;
  description: string;
  url: string;
  thumbnail: string;
}

export function getLocalVideos(): VideoInfo[] {
  return [
    {
      id: "cotton-candy-promo",
      title: "솜사탕쇼 홍보 영상",
      description: "달콤한 솜사탕이 만들어지는 마법 같은 퍼포먼스",
      url: "/videos/cotton-candy-promo.mp4",
      thumbnail: "/images/cotton_candy_v2.png",
    },
    {
      id: "cotton-candy-backup",
      title: "솜사탕쇼 현장 영상",
      description: "아이들이 가장 좋아하는 달콤한 솜사탕 공연",
      url: "/videos/cotton-candy-backup.mp4",
      thumbnail: "/images/cotton_candy_v2.png",
    },
    {
      id: "performance-highlight",
      title: "비버컴퍼니 공연 하이라이트",
      description: "생생한 현장 분위기를 느껴보세요",
      url: "/videos/KakaoTalk_20251021_053432934_1761044919786.mp4",
      thumbnail: "/images/puppet_show_v2.png",
    },
  ];
}
