import Parser from 'rss-parser';

export interface BlogPost {
  title: string;
  link: string;
  pubDate: string;
  description: string;
  category?: string;
  thumbnail?: string;
}

const RSS_URL = 'https://rss.blog.naver.com/eunji6043.xml';
const CACHE_DURATION = 10 * 60 * 1000; // 10분

let cachedPosts: BlogPost[] = [];
let lastFetchTime = 0;

/**
 * RSS 피드에서 블로그 포스팅 가져오기
 */
async function fetchBlogPosts(): Promise<BlogPost[]> {
  const parser = new Parser({
    customFields: {
      item: ['category', 'description', 'content:encoded']
    }
  });

  try {
    console.log('📡 RSS 피드 가져오는 중...', RSS_URL);
    const feed = await parser.parseURL(RSS_URL);
    
    const posts: BlogPost[] = feed.items.map((item, index) => {
      const thumbnail = extractThumbnail(item.content || (item as any)['content:encoded'] || item.description || '');
      const description = extractDescription(item.contentSnippet || item.description || '');
      
      return {
        title: item.title || '',
        link: item.link || '',
        pubDate: item.pubDate || '',
        description: description,
        category: (item as any).category || '',
        thumbnail: thumbnail
      };
    });

    console.log(`✅ ${posts.length}개의 포스팅을 가져왔습니다.`);
    return posts;
  } catch (error) {
    console.error('❌ RSS 피드 가져오기 실패:', error);
    return [];
  }
}

/**
 * 썸네일 이미지 추출 (여러 패턴 시도)
 */
function extractThumbnail(content: string): string {
  if (!content) return '';
  
  // 패턴 1: <img src="..." /> 형식
  let imgMatch = content.match(/<img[^>]+src=["']([^"']+)["']/i);
  if (imgMatch && imgMatch[1]) {
    return imgMatch[1];
  }
  
  // 패턴 2: blogthumb.pstatic.net 또는 phinf.pstatic.net URL
  imgMatch = content.match(/(https?:\/\/(?:blogthumb|phinf)\.pstatic\.net[^\s<>"']+)/i);
  if (imgMatch && imgMatch[1]) {
    return imgMatch[1];
  }
  
  // 패턴 3: 일반 이미지 URL (.jpg, .png, .gif 등)
  imgMatch = content.match(/(https?:\/\/[^\s<>"']+\.(?:jpg|jpeg|png|gif|webp)[^\s<>"']*)/i);
  if (imgMatch && imgMatch[1]) {
    return imgMatch[1];
  }
  
  return '';
}

/**
 * 설명 텍스트 추출 (HTML 태그 제거)
 */
function extractDescription(content: string): string {
  if (!content) return '';
  
  // HTML 태그 제거
  let text = content.replace(/<[^>]+>/g, '');
  
  // HTML 엔티티 디코드
  text = text.replace(/&nbsp;/g, ' ')
             .replace(/&lt;/g, '<')
             .replace(/&gt;/g, '>')
             .replace(/&amp;/g, '&')
             .replace(/&quot;/g, '"')
             .replace(/&#39;/g, "'");
  
  // 연속된 공백 제거
  text = text.replace(/\s+/g, ' ').trim();
  
  // 너무 길면 자르기 (200자)
  if (text.length > 200) {
    text = text.substring(0, 200) + '...';
  }
  
  return text;
}

/**
 * 캐시된 포스팅 가져오기 (10분 캐시)
 */
async function getCachedPosts(): Promise<BlogPost[]> {
  const now = Date.now();
  
  if (cachedPosts.length === 0 || now - lastFetchTime > CACHE_DURATION) {
    cachedPosts = await fetchBlogPosts();
    lastFetchTime = now;
  }
  
  return cachedPosts;
}

/**
 * 여러 키워드로 포스팅 필터링 (OR 조건)
 */
export async function getBlogPostsByKeywords(keywords: string[], limit: number = 10): Promise<BlogPost[]> {
  const posts = await getCachedPosts();

  if (!keywords || keywords.length === 0) {
    return posts.slice(0, limit);
  }

  const searchKeywords = keywords.map(k => k.toLowerCase().trim());

  const filtered = posts.filter(post => {
    const title = (post.title || '').toLowerCase();
    const description = (post.description || '').toLowerCase();
    const category = (post.category || '').toLowerCase();

    return searchKeywords.some(keyword =>
       title.includes(keyword) ||
       description.includes(keyword) ||
       category.includes(keyword)
    );
  });

  return filtered.slice(0, limit);
}
