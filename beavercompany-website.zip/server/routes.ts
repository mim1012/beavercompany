import type { Express } from "express";
import { createServer, type Server } from "http";
import { getBlogPostsByKeywords } from "./services/blog";
import { getYoutubeVideos } from "./services/youtube";

export function registerRoutes(app: Express): Server {
  // Blog API
  app.get("/api/blog", async (req, res) => {
    try {
      const keywords = ["공연", "후기", "인형극", "마술", "버블", "솜사탕"];
      const posts = await getBlogPostsByKeywords(keywords, 3);
      res.json(posts);
    } catch (error) {
      console.error("Failed to fetch blog posts:", error);
      res.status(500).json({ error: "Failed to fetch blog posts" });
    }
  });

  // YouTube API
  app.get("/api/youtube", async (req, res) => {
    try {
      const videos = await getYoutubeVideos(3);
      res.json(videos);
    } catch (error) {
      console.error("Failed to fetch youtube videos:", error);
      res.status(500).json({ error: "Failed to fetch youtube videos" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
