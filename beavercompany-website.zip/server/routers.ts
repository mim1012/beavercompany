import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createConsultation, getConsultations } from "./db";
import { notifyOwner } from "./_core/notification";
import { sendContactNotification } from "./_core/email";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  // 상담 신청 API
  consultation: router({
    // 상담 신청 제출
    submit: publicProcedure
      .input(
        z.object({
          organization: z.string().min(1, "기관명을 입력해주세요"),
          phone: z.string().min(1, "연락처를 입력해주세요"),
          performance: z.string().optional(),
          date: z.string().optional(),
          message: z.string().min(1, "문의 내용을 입력해주세요"),
          // 유입 경로 정보 (선택)
          source: z.string().optional(),
          medium: z.string().optional(),
          campaign: z.string().optional(),
          referrerUrl: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        // 유입 경로 표시 텍스트
        const sourceLabel = input.source || "직접 접속";
        const mediumLabel = input.medium || "direct";

        // 데이터베이스에 저장
        const consultation = await createConsultation(input);

        // 관리자에게 알림 전송 (유입 경로 포함)
        await notifyOwner({
          title: `🎭 새 공연 문의 - ${input.organization} [${sourceLabel}]`,
          content: `기관명: ${input.organization}\n연락처: ${input.phone}\n희망 공연: ${input.performance || "미선택"}\n희망 날짜: ${input.date || "미정"}\n문의 내용: ${input.message}\n\n📊 유입 경로: ${sourceLabel} (${mediumLabel})${input.campaign ? `\n캠페인: ${input.campaign}` : ""}${input.referrerUrl ? `\n레퍼러: ${input.referrerUrl}` : ""}`,
        });

        // 이메일로 알림 전송 (유입 경로 포함)
        await sendContactNotification({
          name: input.organization,
          phone: input.phone,
          message: input.message,
          programType: input.performance,
          preferredDate: input.date,
          source: sourceLabel,
          medium: mediumLabel,
          campaign: input.campaign,
          referrerUrl: input.referrerUrl,
        });

        return {
          success: true,
          consultationId: consultation.id,
        };
      }),
    // 상담 신청 목록 조회 (관리자용)
    list: publicProcedure.query(async () => {
      return await getConsultations();
    }),
  }),
  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
