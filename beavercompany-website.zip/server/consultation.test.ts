import { describe, it, expect, beforeAll } from 'vitest';
import { appRouter } from './routers';

let caller: ReturnType<typeof appRouter.createCaller>;

beforeAll(() => {
  caller = appRouter.createCaller({ user: undefined });
});

describe('Consultation API', () => {
  it('should submit a consultation successfully', async () => {

    const result = await caller.consultation.submit({
      organization: '테스트 유치원',
      phone: '010-1234-5678',
      performance: '솜사탕쇼',
      date: '2026-03-15',
      message: '3월 15일 공연 문의드립니다.',
    });

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
    expect(result.consultationId).toBeGreaterThan(0);
  });

  it('should fail when required fields are missing', async () => {

    await expect(
      caller.consultation.submit({
        organization: '',
        phone: '010-1234-5678',
        performance: '',
        date: '',
        message: '',
      })
    ).rejects.toThrow();
  });

  it('should retrieve consultation list', async () => {

    const list = await caller.consultation.list();

    expect(Array.isArray(list)).toBe(true);
  });
});
