/**
 * 비버컴퍼니 GA4 이벤트 트래킹 유틸리티
 * Google Analytics 4 이벤트를 일관되게 전송하기 위한 헬퍼 함수 모음
 */

declare global {
  interface Window {
    gtag?: (...args: any[]) => void;
    dataLayer?: any[];
    trackEvent?: (eventName: string, params?: Record<string, any>) => void;
  }
}

/** GA4 이벤트 전송 기본 함수 */
export function trackEvent(eventName: string, params?: Record<string, any>) {
  if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
    window.gtag('event', eventName, {
      ...params,
      send_to: import.meta.env.VITE_GA_MEASUREMENT_ID,
    });
  }
}

/** 전화 버튼 클릭 트래킹 */
export function trackPhoneClick(location: string = 'unknown') {
  trackEvent('phone_click', {
    event_category: 'contact',
    event_label: '전화 상담 클릭',
    contact_location: location,  // 'header' | 'hero' | 'footer' | 'mobile_cta'
    value: 1,
  });
}

/** 카카오톡 버튼 클릭 트래킹 */
export function trackKakaoClick(location: string = 'unknown') {
  trackEvent('kakao_click', {
    event_category: 'contact',
    event_label: '카카오톡 문의 클릭',
    contact_location: location,
    value: 1,
  });
}

/** 상담 신청 폼 제출 트래킹 */
export function trackConsultationSubmit(performance?: string) {
  trackEvent('consultation_submit', {
    event_category: 'conversion',
    event_label: '상담 신청 완료',
    performance_type: performance || '미선택',
    value: 10,
  });
  // GA4 표준 전환 이벤트
  trackEvent('generate_lead', {
    currency: 'KRW',
    value: 10,
  });
}

/** 공연 프로그램 카드 클릭 트래킹 */
export function trackProgramClick(programName: string) {
  trackEvent('program_click', {
    event_category: 'engagement',
    event_label: programName,
    item_name: programName,
  });
}

/** 영상 재생 트래킹 */
export function trackVideoPlay(videoTitle: string) {
  trackEvent('video_play', {
    event_category: 'engagement',
    event_label: videoTitle,
    video_title: videoTitle,
  });
}

/** 블로그 포스팅 클릭 트래킹 */
export function trackBlogClick(postTitle: string) {
  trackEvent('blog_click', {
    event_category: 'engagement',
    event_label: postTitle,
  });
}

/** 스크롤 깊이 트래킹 (섹션 도달) */
export function trackSectionView(sectionName: string) {
  trackEvent('section_view', {
    event_category: 'scroll',
    event_label: sectionName,
    section_name: sectionName,
  });
}

/** 페이지 뷰 트래킹 (SPA용) */
export function trackPageView(path: string, title: string) {
  if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
    window.gtag('config', import.meta.env.VITE_GA_MEASUREMENT_ID || '', {
      page_path: path,
      page_title: title,
    });
  }
}
