import { Calendar, MessageCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function MobileBottomCTA() {
  const handleScroll = (targetId: string) => {
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-white border-t border-stone-200 shadow-[0_-4px_16px_rgba(0,0,0,0.08)]">
      <div className="container px-4 py-4">
        <div className="flex items-center justify-end gap-3">
          {/* 전화 버튼 */}
          <Button
            onClick={() => window.location.href = "tel:010-4808-9382"}
            className="w-14 h-14 rounded-full bg-white border-2 border-stone-300 text-stone-800 hover:bg-stone-50 hover:border-stone-400 shadow-md transition-all p-0 flex items-center justify-center"
          >
            <Phone className="w-6 h-6" />
          </Button>

          {/* 카카오톡 버튼 */}
          <Button
            onClick={() => window.open("https://pf.kakao.com/_rXDin/chat", "_blank")}
            className="w-14 h-14 rounded-full bg-[#FEE500] text-stone-900 hover:bg-[#FDD835] shadow-md transition-all border-0 p-0 flex items-center justify-center"
          >
            <MessageCircle className="w-6 h-6" />
          </Button>

          {/* 예약 문의 버튼 */}
          <Button
            onClick={() => handleScroll("contact")}
            className="w-14 h-14 rounded-full bg-blue-600 text-white hover:bg-blue-700 shadow-lg transition-all p-0 flex items-center justify-center"
          >
            <Calendar className="w-6 h-6" />
          </Button>
        </div>
      </div>
    </div>
  );
}
